# @rk/ui — дизайн-система «Русский код»

Самодостаточный модуль дизайн-системы (направление «икона × авангард × космизм»): дизайн-токены (CSS), бренд-ассеты (логотипы, иконки категорий, акварельные иллюстрации) и **типизированные React-компоненты** — включая слой графа знаний **«Гиперинформация»** (`knowledge/*`).

Собран через `tsup` в `dist/` (ESM + `.d.ts`), `react`/`react-dom` — peer-зависимости. Подходит для переиспользования в дочерних проектах (напр. «Гиперинформация»).

## Установка (в дочернем проекте)

Монорепо: `"@rk/ui": "workspace:*"`. Вне монорепо — через приватный реестр или `file:`/tarball (`pnpm pack`).

```bash
pnpm add @rk/ui react react-dom
```

## Использование

```tsx
import "@rk/ui/styles.css";              // токены + шрифты (один файл, @import внутри)
import { Button, MatrixBoard, ConnectionGraph, EntityPill } from "@rk/ui";

export default function Page() {
  return (
    <>
      <Button variant="cta">Отметить</Button>
      <MatrixBoard />
      <EntityPill type="person" label="С. Рахманинов" sub="1873–1943" />
    </>
  );
}
```

- **Стили:** импортируйте `@rk/ui/styles.css` один раз в корне (определяет все CSS-переменные `--paper`, `--cinnabar`, `--era-*`, `--graph-*`, `--node-*`, `--conf-*` …). Тёмная тема — `data-theme="dark"` на `<html>`.
- **Типы:** полные `.d.ts` идут в комплекте (`exports.types`).
- **Клиентские компоненты:** бандл помечен `"use client"` — в Next.js App Router импортируйте из клиентских компонентов/страниц.

## Бренд-ассеты

Иллюстрации и логотипы лежат в `@rk/ui/brand/*` (`@rk/ui/brand/illustrations/<name>.svg`, `@rk/ui/brand/logo-lockup.svg`, …). Компоненты `Illustration`/`EmptyState`/`EraRoadmap` по умолчанию ждут их по абсолютному пути `"/brand/illustrations"`, поэтому скопируйте `dist/brand` в `public/brand` приложения (или передайте проп `assetBase`).

## Состав

- **UI-примитивы:** `Button`, `Field`/`TextField`/`Textarea`/`SearchField`/`Select`/`Checkbox`/`Radio`/`Switch`/`StarRating`, `TabBar`/`AppHeader`/`Tabs`, `Sheet`/`Modal`/`Toast`, `ProgressBar`/`ProgressRing`/`FilterChip`/`EmptyState`/`Avatar`, `Icon`.
- **Бренд/контент:** `EraMark`, `CategoryIcon`/`CategoryChip`/`Badge`/`BadgeMedallion`, `Illustration`, `Card`/`ItemCard`/`WhyBlock`/`StageHeader`/`Timeline`/`EraRoadmap`/`MatrixBoard`/`CompletionSheet`/`MemoryTimeline`/`PhotoTile`.
- **Коды/паспорт/медиа/календарь/аккаунт:** `CodeCard`/`CodeReveal`/`Quiz`, `PassportPreview`/`ShareCard`, `ActivityIcon`/`ProviderIcon`/`MediaLinkRow`, `EventCard`/`CodeOfWeekCard`, `AuthButton`/`ProfileSetup`/`ProfileSwitcher`/`SettingRow`/`ConsentNotice`/`OnboardingSlide`.
- **Граф знаний «Гиперинформация»:** `ConnectionGraph`, `EntityPill`, `EntityGlyph` (+`ENTITY_TYPES`), `EntityMedallion`, `AnomalyGlyph` (+`ANOMALY_KINDS`), `ConfidenceRing`.

## Сборка

```bash
pnpm --filter @rk/ui build   # tsup → dist (js + d.ts) + копирование styles.css/tokens/brand
pnpm --filter @rk/ui dev     # watch
```
